export type ChipMessages = {
  dismissLabel: string;
};
