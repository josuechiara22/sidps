export type ActionPadMessages = {
  expand: string;
  collapse: string;
};
