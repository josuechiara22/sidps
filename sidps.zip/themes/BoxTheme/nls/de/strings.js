define({
  "_themeLabel": "Box-Design",
  "_layout_default": "Standard-Layout",
  "_layout_top": "Oberes Layout"
});