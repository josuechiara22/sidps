define({
  "_widgetLabel": "Ovládač Box"
});