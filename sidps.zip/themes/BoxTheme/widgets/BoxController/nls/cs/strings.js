define({
  "_widgetLabel": "Ovladač rámečku"
});