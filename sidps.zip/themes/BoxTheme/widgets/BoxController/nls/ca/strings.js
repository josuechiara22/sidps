define({
  "_widgetLabel": "Controlador de quadre"
});