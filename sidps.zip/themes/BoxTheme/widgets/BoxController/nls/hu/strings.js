define({
  "_widgetLabel": "Box vezérlő"
});